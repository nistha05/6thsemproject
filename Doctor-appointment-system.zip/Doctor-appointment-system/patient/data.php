<?php
$dataset = array(
    "Ram Prasad" => array(
        "Cardiology" => 5
    ),
    "Gyanendra Joshi" => array(
        "Neurology" => 5
    ),
    "Jenny Gautam" => array(
        "Orthopedics" => 5
    ),
    "Abinandan Udash" => array(
        "Dermatology" => 5
    ),
    "Chanda Jaiswal" => array(
        "Pediatrics" => 5
    ),
    "Sankar Bhatta" => array(
        "Endocrinology" => 5
    ),
    "Jenny Pant" => array(
        "Clinical chemistry" => 5
    ),
    "Kaliparasad Koirala" => array(
        "Orthopedics" => 5
    ),
    "Nistha Joshi" => array(
        "Neurology" => 5
    ),
    "Harilal Yadav" => array(
        "Cardiology" => 5
    ),
    "Sarita Rai" => array(
        "Cardiology" => 5
    ),
    "Padam Chand" => array(
        "Allergology" => 5
    ),
    "Ram Paneru" => array(
        "Allergology" => 5
    ),
    "Kabita Gurung" => array(
        "Dermatology" => 5
    ),
    "Param Rai" => array(
        "Dermatology" => 5
    ),
    "Ram Pal" => array(
        "Cardiology" => 5
    )
);
?>
